import org.w3c.dom.Node;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Mahasiswa {
        public void main(String[] args) throws Exception {
            BufferedReader kata = new BufferedReader(new InputStreamReader(System.in));
            // Class Buffered menjadi variabel baru bernama kata
            int a; // Mendeklarasikan variable bernama a bertipe data integer
            System.out.println("Jumlah Nama Yang Di Inputkan ;");
            a = Integer.parseInt(kata.readLine()); // mengconvert a yang asalnya

            String[] Array; // mendeklarasikan array yang bertipe data string
            Array = new String[a]; // instansiasi dan inisialisasi variable a
            String temp; // mendeklarasikan variabel temp yang bertipe data string
            // penginputan nama
            for (int i = 0; i < a; i++) {
                System.out.print("Nama " + (i + 1) + " adalah: ");
                Node path_input = null;
            }
            // proses penyortingan
            for (int x = 1; x < a; x++) {
                for (int y = 0; y < a - x; y++) {
                    if (Array[y].compareTo(Array[y + 1]) > 0) {
                        temp = Array[y];//gilang, bagus, iban, riyan, dewi, daniel, zidni, naimah, arul, zaki, juli, yanuar,yani,yusril
                        Array[y] = Array[y + 1];//gilang, bagus, iban, riyan, dewi, daniel, zidni, naimah, arul, zaki, juli, yanuar,yani,yusril
                        Array[y + 1] = temp; //adita, gilang, alwan, riyan, dewi, daniel, zidni, naimah, arul, zaki, juli, yanuar,yani,yusril
                    }
                }
            }
            // output pengurutan nama
            System.out.println("");
            System.out.println("Urutannya ");

            for (int i = 0; i < a; i++) {
                System.out.println((i + 1) + ". " + Array[i]);
            }
            // output dari jumlah siswa
            System.out.println("Jumlah siswa : " + a);
            System.out.println("nama 2 terbawah : " + Array[a - 2]);
            System.out.println("nama 2 teratas : " + Array[1]);
        }
    }