public class urutannama {

    public static void main(String[] args) {
        String[] nama = {"Windy","Budi","sUsI","aGUS","beNI"};
        //String[] nama = {"Windy","Budi","Susi","Agus","Beni"};
        InsertionSort _pleaseSort = new InsertionSort();
        _pleaseSort.setData(nama);
        _pleaseSort.insertionSort();
        _pleaseSort.PrintSortedData();
    }
}
